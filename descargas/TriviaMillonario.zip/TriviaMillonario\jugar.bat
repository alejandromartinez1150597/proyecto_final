@echo off
cd /d "%~dp0"
where java >nul 2>nul
if errorlevel 1 (
    echo Para jugar necesitas instalar Java 17 o superior: https://adoptium.net
    pause
    exit /b
)
java -jar TriviaMillonario.jar
pause
